package com.example.android3hw.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.android3hw.databinding.ItemCartBinding
import com.example.android3hw.model.CartItem

class CartViewHolder(
    val binding: ItemCartBinding
) : RecyclerView.ViewHolder(binding.root)

class CartAdapter(
    val items: MutableList<CartItem>,
    private val onRemoveFromCart: (Int) -> Unit
) : RecyclerView.Adapter<CartViewHolder>() {

    override fun getItemCount(): Int {
        return items.size
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        //add..................................
        

    }


}