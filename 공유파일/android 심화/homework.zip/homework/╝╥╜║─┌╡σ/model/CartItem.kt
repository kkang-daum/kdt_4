package com.example.android3hw.model

data class CartItem(val id: Int, val name: String, val price: Int, val quantity: Int)