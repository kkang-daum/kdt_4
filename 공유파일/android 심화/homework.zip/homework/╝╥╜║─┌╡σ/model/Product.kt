package com.example.android3hw.model

data class Product(
    val id: Int,
    val name: String,
    val price: Int,
    val imageRes: Int = 0 // 이미지 리소스
)