package com.example.android3hw.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.android3hw.adapter.ProductAdapter
import com.example.android3hw.databinding.FragmentProductListBinding
import com.example.android3hw.model.Product
import com.example.android3hw.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class ProductListFragment : Fragment() {

    lateinit var binding: FragmentProductListBinding

    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: ProductAdapter

    lateinit var products: MutableList<Product>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProductListBinding.inflate(inflater, container, false)

        // 상품 목록 (더미 데이터)
        products = mutableListOf(
            Product(1, "Product 1", 1000),
            Product(2, "Product 2", 2000),
            Product(3, "Product 3", 3000),
            Product(4, "Product 4", 4000),
            Product(5, "Product 5", 5000),
            Product(6, "Product 6", 6000)
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeCartStatus()
    }

    private fun setupRecyclerView() {
        //add............... 초기 recyclerview 구성
        
    }

    private fun observeCartStatus() {
        //add............. flow 구독...................
        
    }

}