package com.example.android3hw.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.android3hw.data.ReactiveShoppingCart
import com.example.android3hw.model.CartItem
import com.example.android3hw.model.Product
import kotlinx.coroutines.flow.StateFlow

class MainViewModel : ViewModel() {

    //add...........................................
    
}