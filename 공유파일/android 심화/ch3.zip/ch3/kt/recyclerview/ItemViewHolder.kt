package com.example.ch3.section2_mission.recyclerview

import androidx.recyclerview.widget.RecyclerView
import com.example.ch3.databinding.ItemMainBinding


class ItemViewHolder(val binding: ItemMainBinding): RecyclerView.ViewHolder(binding.root)