package com.example.ch3.section2_mission.model


data class PageList(
    var id: Long,
    var totalResults: Long,
    var articles: List<Item>
)